﻿using NotePad___WPF.Commands;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.IO.Packaging;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using static System.Net.Mime.MediaTypeNames;

namespace NotePad___WPF
{
    internal class MainWindowViewModel : INotifyPropertyChanged
    {
        private string? _address;
        private string? _rich_txt="";
        public NotePad___WPF.Commands.MyRelayCommand? cmd_Load { get ; set; }
        private object _view;
        public MyRelayCommand cmd_Paste { get; set; }
        public MyRelayCommand cmd_Save { get; set; }
        public MyRelayCommand cmd_Copy { get; set; }
        public MyRelayCommand cmd_SelectAll { get; set; }
        public string? RichText { get=>_rich_txt; set { _rich_txt = value; OnPropertyChanged(); } }
        public string Address { 
            get { return _address; } 
            set { _address = value; OnPropertyChanged(); } 
        }

        public MainWindowViewModel(object view)
        {
            Address = "";
            cmd_Load = new MyRelayCommand(Load, CanLoad);
            cmd_Save = new MyRelayCommand(Save);
            cmd_Paste=new MyRelayCommand(Paste, CanPaste);
            cmd_Copy = new MyRelayCommand(Copy);

            cmd_SelectAll = new MyRelayCommand((object parameter) => { MessageBox.Show("islemir :)"); });
        }

        private void Load(object? obj)// address yazarken bu numunedeki kimi escape sequence istifade edin : C:\\Users\\Sevgi\\Desktop\\Ioc Container.txt
        {
            if (!(File.Exists(Address)))
            {
                MessageBox.Show("Verilen address movcud deyil ve ya yanlisdir.");
                return;
            }
            try
            {
                using(StreamReader reader = new StreamReader(Address))
                {
                    string text = reader.ReadToEnd();
                    RichText = text;
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Sorry! This file can't be opened!");
            }


        }
        private void Copy(object parameter)
        {
            Clipboard.SetText(RichText);
        }

        private bool CanLoad(object? obj)
        {
            return Address.Length > 6;
               
        }
        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string propertyName=null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

       

        private void Save(object parameter)
        {
            if (!(File.Exists(Address)))
            {
                MessageBox.Show("Verilen address movcud deyil ve ya yanlisdir.");
                return;
            }
            try
            {
                
                using (StreamWriter reader = new StreamWriter(Address))
                {
                    reader.WriteLine(RichText);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Sorry! This file can't be opened!");
            }


        }
        
        private void Paste(object parameter) {
            RichText += Clipboard.GetText();
        }
        private bool CanPaste(object parameter) { return Clipboard.ContainsText(); }
    }
}
